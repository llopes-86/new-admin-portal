const CONFIG = {
  PB_URL: '/api/pb',
};
