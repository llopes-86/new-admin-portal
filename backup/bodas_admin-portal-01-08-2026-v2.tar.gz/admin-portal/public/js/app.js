(async () => {
  const auth = requireAuth();
  if (!auth) return;

  const mustChange = await checkMustChangePassword();
  if (mustChange) { window.location.replace('index.html'); return; }

  let currentTab = 'guests';
  let switching = false;

  function switchTab(tab) {
    if (switching) return;
    switching = true;
    currentTab = tab;
    $$('.tab-content').forEach(el => el.classList.remove('active'));
    $(`#tab-${tab}`).classList.add('active');
    $$('.nav-item').forEach(el => el.classList.remove('active'));
    const navItem = $(`.nav-item[data-tab="${tab}"]`);
    if (navItem) navItem.classList.add('active');
    $$('.bottom-nav-item[data-tab]').forEach(el => el.classList.remove('active'));
    const bnItem = $(`.bottom-nav-item[data-tab="${tab}"]`);
    if (bnItem) bnItem.classList.add('active');

    const titles = { guests: 'Convidados Confirmados', messages: 'Mensagens do Mural' };
    const titleEl = $('#tab-title');
    if (titleEl) titleEl.textContent = titles[tab] || tab;

    const statsG = $('#stats-guests');
    if (statsG) statsG.classList.toggle('hidden', tab !== 'guests');
    const statsM = $('#stats-messages');
    if (statsM) statsM.classList.toggle('hidden', tab !== 'messages');

    if (tab === 'guests') Guests.load();
    else if (tab === 'messages') Messages.load();
    switching = false;
  }

  $$('.nav-item[data-tab]').forEach(btn => {
    btn.addEventListener('click', () => switchTab(btn.dataset.tab));
  });

  $$('.bottom-nav-item[data-tab]').forEach(btn => {
    btn.addEventListener('click', () => switchTab(btn.dataset.tab));
  });

  const logoutBtn = $('#logout-btn');
  if (logoutBtn) logoutBtn.addEventListener('click', logout);

  const logoutMobile = $('#logout-btn-mobile');
  if (logoutMobile) logoutMobile.addEventListener('click', logout);

  const exportBtn = $('#export-btn');
  if (exportBtn) exportBtn.addEventListener('click', showExportModal);
  const exportMobile = $('#export-btn-mobile');
  if (exportMobile) exportMobile.addEventListener('click', showExportModal);

  const search = $('#guests-search');
  if (search) search.addEventListener('input', () => Guests.applyFilters());
  const guestFilter = $('#guests-filter');
  if (guestFilter) guestFilter.addEventListener('change', () => Guests.applyFilters());
  const guestCatFilter = $('#guests-category-filter');
  if (guestCatFilter) guestCatFilter.addEventListener('change', () => Guests.applyFilters());
  const msgFilter = $('#messages-filter');
  if (msgFilter) msgFilter.addEventListener('change', () => Messages.applyFilters());

  renderUserInfo();

  switchTab('guests');
  Messages.load();
})();

function renderUserInfo() {
  const auth = getAuth();
  if (!auth?.user) return;
  const email = auth.user.email || '';
  const initial = email.charAt(0).toUpperCase();

  const elD = $('#user-email');
  if (elD) elD.textContent = email;
  const elI = $('#user-initial');
  if (elI) elI.textContent = initial;
  const elM = $('#user-email-mobile');
  if (elM) elM.textContent = email;
  const elIM = $('#user-initial-mobile');
  if (elIM) elIM.textContent = initial;
}

function showModal(title, bodyHTML, onConfirm) {
  const existing = $('#modal-overlay');
  if (existing) existing.remove();

  const overlay = document.createElement('div');
  overlay.id = 'modal-overlay';
  overlay.className = 'modal-overlay';
  overlay.innerHTML = `
    <div class="modal-dialog">
      <div class="modal-title">${title}</div>
      <div class="modal-body">${bodyHTML}</div>
      <div class="modal-actions">
        <button class="btn btn-outline" data-action="cancel">Cancelar</button>
        <button class="btn btn-primary" data-action="confirm">Confirmar</button>
      </div>
    </div>`;

  overlay.addEventListener('click', e => {
    if (e.target === overlay) overlay.remove();
  });
  overlay.querySelector('[data-action="cancel"]').addEventListener('click', () => overlay.remove());
  overlay.querySelector('[data-action="confirm"]').addEventListener('click', () => {
    overlay.remove();
    if (onConfirm) onConfirm();
  });

  document.body.appendChild(overlay);
}

function showExportModal() {
  const existing = $('#modal-overlay');
  if (existing) existing.remove();

  const guestCount = Guests.filtered ? Guests.filtered.length : 0;
  const msgCount = Messages.filtered ? Messages.filtered.length : 0;

  if (guestCount === 0 && msgCount === 0) {
    showToast('Nenhum registro para exportar.', 'error');
    return;
  }

  const overlay = document.createElement('div');
  overlay.id = 'modal-overlay';
  overlay.className = 'modal-overlay';
  overlay.innerHTML = `
    <div class="modal-dialog" style="max-width:460px">
      <div class="modal-title">Exportar Dados</div>
      <div class="modal-body">
        <label class="checkbox-label">
          <input type="checkbox" id="export-guests"${guestCount > 0 ? ' checked' : ''}>
          <span>Convidados (${guestCount} registros)</span>
        </label>
        <label class="checkbox-label">
          <input type="checkbox" id="export-messages"${msgCount > 0 ? ' checked' : ''}>
          <span>Mural (${msgCount} mensagens)</span>
        </label>
      </div>
      <div class="modal-actions">
        <button class="btn btn-outline" data-action="cancel">Cancelar</button>
        <button class="btn btn-primary" data-action="pdf">Exportar PDF</button>
        <button class="btn btn-primary" data-action="xlsx">Exportar Excel</button>
      </div>
    </div>`;

  overlay.addEventListener('click', e => {
    if (e.target === overlay) overlay.remove();
  });
  overlay.querySelector('[data-action="cancel"]').addEventListener('click', () => overlay.remove());
  overlay.querySelector('[data-action="pdf"]').addEventListener('click', () => {
    const guests = $('#export-guests').checked;
    const messages = $('#export-messages').checked;
    if (!guests && !messages) { showToast('Selecione pelo menos um conjunto de dados.', 'error'); return; }
    overlay.remove();
    Export.gerarPDF({ guests, messages });
  });
  overlay.querySelector('[data-action="xlsx"]').addEventListener('click', () => {
    const guests = $('#export-guests').checked;
    const messages = $('#export-messages').checked;
    if (!guests && !messages) { showToast('Selecione pelo menos um conjunto de dados.', 'error'); return; }
    overlay.remove();
    Export.gerarXLSX({ guests, messages });
  });

  document.body.appendChild(overlay);
}
