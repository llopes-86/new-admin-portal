class SessionAuthStore {
  constructor(key = 'pb_auth') {
    this._key = key;
    this._listeners = [];
  }
  _read() {
    try { return JSON.parse(sessionStorage.getItem(this._key) || 'null') || {}; }
    catch (_) { return {}; }
  }
  _write(data) {
    try { sessionStorage.setItem(this._key, JSON.stringify(data)); } catch (_) {}
  }
  get token() { return this._read().token || ''; }
  get record() { return this._read().record || null; }
  get model() { return this.record; }
  get isValid() {
    const t = this.token;
    if (!t) return false;
    try {
      const payload = JSON.parse(atob(t.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')));
      return !payload.exp || (payload.exp * 1000) >= Date.now();
    } catch (_) { return false; }
  }
  get isSuperuser() { return false; }
  save(token, record) {
    this._write({ token, record });
    this._listeners.forEach(fn => fn(token, record));
  }
  clear() {
    sessionStorage.removeItem(this._key);
    this._listeners.forEach(fn => fn(null, null));
  }
  onChange(fn) {
    this._listeners.push(fn);
    return () => { this._listeners = this._listeners.filter(f => f !== fn); };
  }
}

const pb = new PocketBase(CONFIG.PB_URL, new SessionAuthStore());
pb.autoCancellation(false);

async function login(email, password) {
  try {
    await pb.collection('users').authWithPassword(email, password);
    const rec = pb.authStore.record;
    const mustChange = !!(rec && rec.must_change_password);
    return { ok: true, mustChangePassword: mustChange };
  } catch (err) {
    if (err && (err.status === 400 || err.isAbort)) {
      return { ok: false, error: 'Credenciais inválidas' };
    }
    return { ok: false, error: 'Erro de conexão com o servidor' };
  }
}

async function changePassword(oldPassword, newPassword) {
  try {
    const auth = getAuth();
    if (!auth) return { ok: false, error: 'Sessão expirada. Faça login novamente.' };
    try {
      await pb.collection('users').update(auth.user.id, {
        oldPassword,
        password: newPassword,
        passwordConfirm: newPassword,
        must_change_password: false
      });
    } catch (err) {
      const resp = (err && err.response) || {};
      const data = resp.data || {};
      let msg = resp.message || 'Erro ao alterar senha';
      if (msg.includes('authenticate') || data.oldPassword) msg = 'Senha atual incorreta.';
      return { ok: false, error: msg };
    }
    pb.authStore.clear();
    try {
      await pb.collection('users').authWithPassword(auth.user.email, newPassword);
    } catch (_) {}
    return { ok: true };
  } catch (err) {
    return { ok: false, error: 'Erro de conexão com o servidor' };
  }
}

function logout() {
  pb.authStore.clear();
  window.location.replace('index.html');
}

function getAuth() {
  if (!pb.authStore.isValid) return null;
  const rec = pb.authStore.record;
  if (!rec) return null;
  return {
    token: pb.authStore.token,
    user: { id: rec.id, email: rec.email, name: rec.name }
  };
}

function requireAuth() {
  const auth = getAuth();
  if (!auth) { window.location.replace('index.html'); return null; }
  return auth;
}

async function checkMustChangePassword() {
  const auth = requireAuth();
  if (!auth) return false;
  try {
    const rec = await pb.collection('users').getOne(auth.user.id);
    return !!rec.must_change_password;
  } catch (err) {
    logout();
    return false;
  }
}