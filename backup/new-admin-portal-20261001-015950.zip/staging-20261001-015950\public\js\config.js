const CONFIG = {
  PB_URL: '/api/pb',
  APP_VERSION: '2.0.4',
  SHOW_LOGIN_OVERLAY: true,
  CONFIRM_LOGOUT: true,
};
